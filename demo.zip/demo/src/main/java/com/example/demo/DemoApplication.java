package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;


import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.List;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}

	@Bean
	CommandLineRunner runner(StudentRepo repo, MongoTemplate mongoTemplate)
	{
		return args -> {
			Address address = new Address(
			"England",
					"axdde",
					"12345"
			);
			String email = "saf@gmail.com";
			 Student student = new Student(
				"saf",
			    "Joe",
				"saf@gmail.com",
				Gender.FEMALE,
			 	address,
					List.of("CSE"),
					BigDecimal.TEN,
					LocalDateTime.now()

			 );
			 //Use it to call by a function
			//usingmongodbTemplateandQuery(repo, mongoTemplate, email, student);

			//repo.insert(student);

			//Simple code using lambda function does same function as usingmongodbTemplateandQuery()
			repo.findStudentByEmail(email).ifPresentOrElse(s ->{
				System.out.println(s + "Already exsists");

			}, ()->{
				System.out.println("Inserting students" + student);
				repo.insert(student);
			});

		};
	}

	private static void usingmongodbTemplateandQuery(StudentRepo repo, MongoTemplate mongoTemplate, String email, Student student) {
		Query query = new Query();

		query.addCriteria(Criteria.where("email").is(email));
		List<Student> students= mongoTemplate.find(query, Student.class);

		if(students.size() > 1){
			throw new IllegalStateException("found students with same email."+ email);

		}

		if(students.isEmpty())
		{
			System.out.println("Inserting students" + student);
			repo.insert(student);
		}else
		{
			System.out.println(student + "Already exsists");
		}
	}

}
