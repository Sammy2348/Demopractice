package com.example.demo;

public enum Gender {
    MALE,FEMALE;
    public enum vote {True, False};
}
